This is the baseline files for the RISC-V RV32i simulator.

Compile all files by executing command "make" inside the .../lab1/src directory.
Run the simulator from the same directory using command 
##
##      ./sim.exe ../testing/filename.memfile 
##

Where "filename" is the name of the instruction you wish to run the tests for, or 
any other .memfile present in the testing directory.

